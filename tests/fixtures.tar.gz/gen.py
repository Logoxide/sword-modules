import random
random.seed(7)
books = {"Gen":[31,25], "Ps":[6,6], "Tob":[22], "Matt":[25,23], "John":[51,25,36], "Rev":[20]}
words = "in the beginning God created heaven and earth light darkness waters spirit Ä é ß ἀγάπη שָׁלוֹם".split()
def verse_text(ref, n):
    parts=[]
    for i in range(random.randint(3,25)):
        w=random.choice(words)
        r=random.random()
        if r<0.3: parts.append(f'<w lemma="strong:G{random.randint(1,5600)}" morph="robinson:N-NSM">{w}</w>')
        elif r<0.35: parts.append(f'<transChange type="added">{w}</transChange>')
        else: parts.append(w)
    if n%5==0: parts.append(f'<note type="crossReference" n="a"><reference osisRef="John.3.16">John 3:16</reference></note>')
    if n%7==0: parts.insert(0, '<q who="Jesus" marker="">'); parts.append('</q>')
    return " ".join(parts) + " &amp; end."
out=['<?xml version="1.0" encoding="UTF-8"?>','<osis xmlns="http://www.bibletechnologies.net/2003/OSIS/namespace"><osisText osisIDWork="T" osisRefWork="Bible" xml:lang="en"><header><work osisWork="T"/></header>']
for b,chs in books.items():
    out.append(f'<div type="book" osisID="{b}"><title type="main">Book {b}</title>')
    for c,n in enumerate(chs,1):
        out.append(f'<chapter osisID="{b}.{c}"><title>Chapter {c}</title>')
        for v in range(1,n+1):
            out.append(f'<verse osisID="{b}.{c}.{v}">{verse_text(f"{b}.{c}.{v}",v)}</verse>')
        out.append('</chapter>')
    out.append('</div>')
out.append('</osisText></osis>')
open("test.osis.xml","w").write("\n".join(out))
